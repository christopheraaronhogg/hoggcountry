Scout AT MVP4 NJ/NY/CT production-safe export generated 2026-05-14.
Generated miles are not official. Water reliability/potability is unknown unless verified. Current conditions require live checks.
